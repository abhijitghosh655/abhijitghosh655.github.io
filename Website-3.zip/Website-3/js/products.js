// Products Controller
class Products {
    constructor() {
        this.products = [];
        this.filteredProducts = [];
        this.currentPage = 1;
        this.productsPerPage = 9;
        this.currentFilter = 'all';
        this.init();
    }

    async init() {
        await this.loadProducts();
        this.setupEventListeners();
    }

    async loadProducts() {
        try {
            // Simulate API call to backend
            this.products = await this.fetchProducts();
            this.filteredProducts = [...this.products];
            this.renderProducts();
            this.renderElementFilters();
        } catch (error) {
            console.error('Error loading products:', error);
            this.products = this.getSampleProducts();
            this.filteredProducts = [...this.products];
            this.renderProducts();
            this.renderElementFilters();
        }
    }

    async fetchProducts() {
        // In a real application, this would be:
        // const response = await fetch('/backend/products.php');
        // return await response.json();
        
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve(this.getSampleProducts());
            }, 1500);
        });
    }

    getSampleProducts() {
        return [
            {
                id: 1,
                name: "High Purity Hydrogen Gas",
                description: "99.999% pure hydrogen gas for industrial and research applications",
                price: 45.00,
                element: "H",
                purity: "99.999",
                category: "Gas",
                image: "fas fa-wind",
                stock: 50
            },
            {
                id: 2,
                name: "Deuterium Oxide (Heavy Water)",
                description: "Research grade heavy water for nuclear and spectroscopic applications",
                price: 120.00,
                element: "H",
                purity: "99.98",
                category: "Liquid",
                image: "fas fa-tint",
                stock: 25
            },
            {
                id: 3,
                name: "Oxygen Gas - Medical Grade",
                description: "Ultra-pure oxygen for medical and laboratory use",
                price: 35.00,
                element: "O",
                purity: "99.995",
                category: "Gas",
                image: "fas fa-lungs",
                stock: 100
            },
            {
                id: 4,
                name: "Activated Carbon Powder",
                description: "High surface area activated carbon for filtration and purification",
                price: 65.00,
                element: "C",
                purity: "99.9",
                category: "Solid",
                image: "fas fa-filter",
                stock: 200
            },
            {
                id: 5,
                name: "Copper Sulfate Pentahydrate",
                description: "ACS reagent grade for agriculture and industrial applications",
                price: 28.00,
                element: "Cu",
                purity: "99.0",
                category: "Solid",
                image: "fas fa-seedling",
                stock: 150
            },
            {
                id: 6,
                name: "Silver Nitrate Crystals",
                description: "Laboratory grade for analytical chemistry and photography",
                price: 85.00,
                element: "Ag",
                purity: "99.8",
                category: "Solid",
                image: "fas fa-vial",
                stock: 75
            },
            {
                id: 7,
                name: "Gold Sputtering Target",
                description: "High purity gold target for thin film deposition",
                price: 850.00,
                element: "Au",
                purity: "99.99",
                category: "Solid",
                image: "fas fa-compact-disc",
                stock: 10
            },
            {
                id: 8,
                name: "Iron Powder - 99.9%",
                description: "Fine iron powder for metallurgy and magnetic applications",
                price: 38.00,
                element: "Fe",
                purity: "99.9",
                category: "Solid",
                image: "fas fa-magnet",
                stock: 300
            },
            {
                id: 9,
                name: "Aluminum Foil - High Purity",
                description: "99.9% pure aluminum foil for laboratory and research use",
                price: 25.00,
                element: "Al",
                purity: "99.9",
                category: "Solid",
                image: "fas fa-layer-group",
                stock: 500
            }
        ];
    }

    renderProducts() {
        const grid = document.getElementById('productsGrid');
        const startIndex = (this.currentPage - 1) * this.productsPerPage;
        const endIndex = startIndex + this.productsPerPage;
        const productsToShow = this.filteredProducts.slice(startIndex, endIndex);

        if (productsToShow.length === 0) {
            grid.innerHTML = '<div class="no-products"><p>No products found matching your criteria.</p></div>';
            return;
        }

        grid.innerHTML = productsToShow.map(product => `
            <div class="product-card fade-in">
                ${product.stock < 10 ? '<div class="product-badge">Low Stock</div>' : ''}
                <div class="product-image">
                    <i class="${product.image}"></i>
                </div>
                <div class="product-content">
                    <h3 class="product-title">${product.name}</h3>
                    <p class="product-description">${product.description}</p>
                    <div class="product-meta">
                        <div class="product-price">$${product.price}</div>
                        <div class="product-purity">${product.purity}%</div>
                    </div>
                    <div class="product-actions">
                        <div class="quantity-controls">
                            <button class="quantity-btn" onclick="this.parentElement.querySelector('span').textContent = Math.max(1, parseInt(this.parentElement.querySelector('span').textContent) - 1)">-</button>
                            <span>1</span>
                            <button class="quantity-btn" onclick="this.parentElement.querySelector('span').textContent = parseInt(this.parentElement.querySelector('span').textContent) + 1">+</button>
                        </div>
                        <button class="add-to-cart" onclick="products.addToCart(${product.id})">
                            <i class="fas fa-cart-plus"></i> Add to Cart
                        </button>
                    </div>
                </div>
            </div>
        `).join('');
    }

    renderElementFilters() {
        const filtersContainer = document.getElementById('elementFilters');
        const elements = [...new Set(this.products.map(p => p.element))];
        
        filtersContainer.innerHTML = `
            <div class="element-filter ${this.currentFilter === 'all' ? 'active' : ''}" data-element="all">
                <i class="fas fa-layer-group"></i>
                <span>All Elements</span>
            </div>
        `;
        
        elements.forEach(element => {
            const filter = document.createElement('div');
            filter.className = `element-filter ${this.currentFilter === element ? 'active' : ''}`;
            filter.setAttribute('data-element', element);
            filter.innerHTML = `
                <i class="fas fa-atom"></i>
                <span>${element}</span>
            `;
            filter.addEventListener('click', () => {
                this.filterByElement(element);
            });
            filtersContainer.appendChild(filter);
        });

        // Add event listener for "All Elements"
        filtersContainer.querySelector('[data-element="all"]').addEventListener('click', () => {
            this.filterByElement('all');
        });
    }

    setupEventListeners() {
        // Purity filters
        document.querySelectorAll('.purity-filters input').forEach(checkbox => {
            checkbox.addEventListener('change', () => {
                this.applyFilters();
            });
        });

        // Element filters are set up in renderElementFilters
    }

    filterByElement(element) {
        this.currentFilter = element;
        
        // Update active filter
        document.querySelectorAll('.element-filter').forEach(filter => {
            filter.classList.remove('active');
        });
        document.querySelector(`[data-element="${element}"]`).classList.add('active');

        this.applyFilters();
    }

    applyFilters() {
        let filtered = [...this.products];
        
        // Filter by element
        if (this.currentFilter !== 'all') {
            filtered = filtered.filter(product => product.element === this.currentFilter);
        }
        
        // Filter by purity
        const selectedPurities = Array.from(document.querySelectorAll('.purity-filters input:checked'))
            .map(checkbox => checkbox.value);
        
        if (selectedPurities.length > 0) {
            filtered = filtered.filter(product => 
                selectedPurities.includes(product.purity)
            );
        }
        
        this.filteredProducts = filtered;
        this.currentPage = 1;
        this.renderProducts();
    }

    filterProducts(query) {
        if (!query) {
            this.filteredProducts = [...this.products];
        } else {
            const searchTerm = query.toLowerCase();
            this.filteredProducts = this.products.filter(product =>
                product.name.toLowerCase().includes(searchTerm) ||
                product.description.toLowerCase().includes(searchTerm) ||
                product.element.toLowerCase().includes(searchTerm)
            );
        }
        this.currentPage = 1;
        this.renderProducts();
    }

    showAllProducts() {
        this.filteredProducts = [...this.products];
        this.currentPage = 1;
        this.renderProducts();
    }

    showProductsForElement(elementSymbol) {
        this.filterByElement(elementSymbol);
        app.scrollToSection('#products');
    }

    loadMoreProducts() {
        this.currentPage++;
        this.renderProducts();
        
        // Hide load more button if no more products
        const totalPages = Math.ceil(this.filteredProducts.length / this.productsPerPage);
        if (this.currentPage >= totalPages) {
            document.getElementById('loadMore').style.display = 'none';
        }
    }

    addToCart(productId) {
        const product = this.products.find(p => p.id === productId);
        if (product) {
            const quantity = parseInt(document.querySelector(`.product-card:nth-child(${this.products.indexOf(product) + 1}) .quantity-controls span`).textContent);
            
            for (let i = 0; i < quantity; i++) {
                app.addToCart(product);
            }
        }
    }
}

// Initialize products
const products = new Products();