// Periodic Table Controller
class PeriodicTable {
    constructor() {
        this.elements = [];
        this.filteredElements = [];
        this.currentFilter = 'all';
        this.init();
    }

    async init() {
        await this.loadElements();
        this.renderTable();
        this.setupEventListeners();
    }

    async loadElements() {
        try {
            // In a real application, this would fetch from your backend
            // For now, we'll use the comprehensive dataset
            this.elements = await this.fetchElements();
            this.filteredElements = [...this.elements];
        } catch (error) {
            console.error('Error loading elements:', error);
            this.elements = this.getDefaultElements();
            this.filteredElements = [...this.elements];
        }
    }

    async fetchElements() {
        // Simulate API call
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve(this.getComprehensiveElements());
            }, 1000);
        });
    }

    getComprehensiveElements() {
        // This would be your complete 118 elements dataset
        // For brevity, I'm showing a subset. In practice, you'd have all 118.
        return [
            // Groups 1-2 (Alkali & Alkaline Earth Metals)
            { number: 1, symbol: "H", name: "Hydrogen", category: "nonmetal", mass: "1.008", phase: "Gas" },
            { number: 3, symbol: "Li", name: "Lithium", category: "alkali-metal", mass: "6.94", phase: "Solid" },
            { number: 11, symbol: "Na", name: "Sodium", category: "alkali-metal", mass: "22.990", phase: "Solid" },
            { number: 19, symbol: "K", name: "Potassium", category: "alkali-metal", mass: "39.098", phase: "Solid" },
            { number: 4, symbol: "Be", name: "Beryllium", category: "alkaline-earth-metal", mass: "9.0122", phase: "Solid" },
            { number: 12, symbol: "Mg", name: "Magnesium", category: "alkaline-earth-metal", mass: "24.305", phase: "Solid" },
            { number: 20, symbol: "Ca", name: "Calcium", category: "alkaline-earth-metal", mass: "40.078", phase: "Solid" },
            
            // Transition Metals
            { number: 26, symbol: "Fe", name: "Iron", category: "transition-metal", mass: "55.845", phase: "Solid" },
            { number: 29, symbol: "Cu", name: "Copper", category: "transition-metal", mass: "63.546", phase: "Solid" },
            { number: 30, symbol: "Zn", name: "Zinc", category: "transition-metal", mass: "65.38", phase: "Solid" },
            { number: 47, symbol: "Ag", name: "Silver", category: "transition-metal", mass: "107.87", phase: "Solid" },
            { number: 79, symbol: "Au", name: "Gold", category: "transition-metal", mass: "196.97", phase: "Solid" },
            
            // Other important elements
            { number: 6, symbol: "C", name: "Carbon", category: "nonmetal", mass: "12.011", phase: "Solid" },
            { number: 7, symbol: "N", name: "Nitrogen", category: "nonmetal", mass: "14.007", phase: "Gas" },
            { number: 8, symbol: "O", name: "Oxygen", category: "nonmetal", mass: "15.999", phase: "Gas" },
            { number: 13, symbol: "Al", name: "Aluminum", category: "post-transition-metal", mass: "26.982", phase: "Solid" },
            { number: 14, symbol: "Si", name: "Silicon", category: "metalloid", mass: "28.085", phase: "Solid" },
            { number: 16, symbol: "S", name: "Sulfur", category: "nonmetal", mass: "32.06", phase: "Solid" },
            { number: 17, symbol: "Cl", name: "Chlorine", category: "halogen", mass: "35.45", phase: "Gas" },
            { number: 82, symbol: "Pb", name: "Lead", category: "post-transition-metal", mass: "207.2", phase: "Solid" },
            { number: 92, symbol: "U", name: "Uranium", category: "actinide", mass: "238.03", phase: "Solid" }
        ];
    }

    renderTable() {
        const table = document.getElementById('periodicTable');
        table.innerHTML = '';

        // Create empty grid cells
        for (let i = 0; i < 118; i++) {
            const cell = document.createElement('div');
            cell.className = 'element empty';
            cell.innerHTML = `
                <div class="element-number">${i + 1}</div>
                <div class="element-symbol"></div>
                <div class="element-name"></div>
            `;
            table.appendChild(cell);
        }

        // Place elements in their positions
        this.filteredElements.forEach(element => {
            const position = this.getElementPosition(element.number);
            const cell = table.children[position];
            
            if (cell) {
                cell.className = `element element-pop ${element.category}`;
                cell.innerHTML = `
                    <div class="element-number">${element.number}</div>
                    <div class="element-symbol">${element.symbol}</div>
                    <div class="element-name">${element.name}</div>
                `;
                
                cell.addEventListener('click', () => {
                    this.showElementDetails(element);
                });
            }
        });
    }

    getElementPosition(atomicNumber) {
        // Simplified position mapping
        // In a real implementation, you'd have precise positions for all 118 elements
        const positions = {
            1: 0,    // H
            2: 17,   // He
            3: 18,   // Li
            4: 19,   // Be
            5: 32,   // B
            6: 33,   // C
            7: 34,   // N
            8: 35,   // O
            9: 36,   // F
            10: 37,  // Ne
            11: 54,  // Na
            12: 55,  // Mg
            13: 70,  // Al
            14: 71,  // Si
            15: 72,  // P
            16: 73,  // S
            17: 74,  // Cl
            18: 75,  // Ar
            19: 86,  // K
            20: 87,  // Ca
            // ... and so on for all 118 elements
            26: 95,  // Fe
            29: 98,  // Cu
            30: 99,  // Zn
            47: 117, // Ag
            79: 147, // Au
            82: 150, // Pb
            92: 160  // U
        };
        
        return positions[atomicNumber] || atomicNumber - 1;
    }

    setupEventListeners() {
        // Filter buttons
        document.querySelectorAll('.control-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const filter = e.target.getAttribute('data-filter');
                this.applyFilter(filter);
                
                // Update active button
                document.querySelectorAll('.control-btn').forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
            });
        });

        // Element search
        document.getElementById('elementSearch').addEventListener('input', (e) => {
            this.filterElements(e.target.value);
        });
    }

    applyFilter(category) {
        this.currentFilter = category;
        
        if (category === 'all') {
            this.filteredElements = [...this.elements];
        } else {
            this.filteredElements = this.elements.filter(element => {
                if (category === 'metal') {
                    return ['alkali-metal', 'alkaline-earth-metal', 'transition-metal', 'post-transition-metal'].includes(element.category);
                } else if (category === 'nonmetal') {
                    return ['nonmetal', 'halogen', 'noble-gas'].includes(element.category);
                } else if (category === 'noble') {
                    return element.category === 'noble-gas';
                }
                return element.category === category;
            });
        }
        
        this.renderTable();
    }

    filterElements(query) {
        if (!query) {
            this.filteredElements = [...this.elements];
        } else {
            const searchTerm = query.toLowerCase();
            this.filteredElements = this.elements.filter(element => 
                element.name.toLowerCase().includes(searchTerm) ||
                element.symbol.toLowerCase().includes(searchTerm) ||
                element.number.toString().includes(searchTerm)
            );
        }
        this.renderTable();
    }

    showAllElements() {
        this.filteredElements = [...this.elements];
        this.renderTable();
    }

    showElementDetails(element) {
        this.currentElement = element;
        
        // Update modal content
        document.getElementById('modalElementName').textContent = `${element.name} (${element.symbol})`;
        
        const detailsContainer = document.getElementById('elementDetails');
        detailsContainer.innerHTML = `
            <div class="element-header">
                <div class="element-symbol-large ${element.category}">${element.symbol}</div>
                <div class="element-info">
                    <h3>${element.name}</h3>
                    <p>Atomic Number: ${element.number}</p>
                    <p>Atomic Mass: ${element.mass}</p>
                    <p>Category: ${this.formatCategory(element.category)}</p>
                    <p>Phase: ${element.phase}</p>
                </div>
            </div>
            <div class="element-description">
                <p>${this.getElementDescription(element)}</p>
            </div>
            <div class="element-actions">
                <button class="btn btn-primary" onclick="products.showProductsForElement('${element.symbol}')">
                    View Products
                </button>
            </div>
        `;
        
        // Show modal
        document.getElementById('elementModal').classList.add('active');
        
        // Scroll to products section
        app.scrollToSection('#products');
    }

    formatCategory(category) {
        return category.split('-').map(word => 
            word.charAt(0).toUpperCase() + word.slice(1)
        ).join(' ');
    }

    getElementDescription(element) {
        const descriptions = {
            "H": "Hydrogen is the lightest and most abundant chemical element, constituting roughly 75% of all normal matter in the universe.",
            "O": "Oxygen is a member of the chalcogen group on the periodic table and is a highly reactive nonmetal.",
            "C": "Carbon is a chemical element with symbol C and atomic number 6. It is nonmetallic and tetravalent.",
            "Fe": "Iron is a metal in the first transition series. It is by mass the most common element on Earth.",
            "Cu": "Copper is a soft, malleable, and ductile metal with very high thermal and electrical conductivity.",
            "Au": "Gold is a bright, slightly reddish yellow, dense, soft, malleable, and ductile metal."
        };
        
        return descriptions[element.symbol] || `${element.name} is a chemical element with symbol ${element.symbol} and atomic number ${element.number}.`;
    }
}

// Initialize periodic table
const periodicTable = new PeriodicTable();